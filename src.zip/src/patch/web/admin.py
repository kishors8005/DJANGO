from django.contrib import admin # type: ignore
from .models import Testimonial, promoter,Faq

class TestimonialAdmin (admin.ModelAdmin):
    list_display = ( 'id','name', 'designation', 'description')  # These fields should exist in the Testimonial model

admin.site.register(Testimonial, TestimonialAdmin)


class promoterAdmin (admin.ModelAdmin):
    list_display = ( 'id','name','image')  # These fields should exist in the Testimonial model


admin.site.register(promoter, promoterAdmin )


class  FaqAdmin (admin.ModelAdmin):
    list_display = ( "id","title","Faq_type","description")  # These fields should exist in the Testimonial model


admin.site.register( Faq,FaqAdmin )


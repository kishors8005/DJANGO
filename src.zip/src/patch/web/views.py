from urllib import request
from django.shortcuts import render  # type: ignore
from web.models import Testimonial, promoter,Faq

def index(request):
    testimonials = Testimonial.objects.all()
    promoters = promoter.objects.all()
    rent_tracking_faqs=Faq.objects.filter(Faq_type="rent_tracking")
    new_deposit_faqs=Faq.objects.filter(Faq_type="new_deposit")
    existing_deposit_faqs=Faq.objects.filter(Faq_type="existing_deposit")
    # Corrected indentation for the print statement

    # Corrected indentation for the context dictionary
    context = {
        "testimonials": testimonials,
        "promoters": promoters,
        "rent_tracking_faqs" :rent_tracking_faqs,
        "new_deposit_faqs" : new_deposit_faqs,
        "existing_deposit_faqs" : existing_deposit_faqs
     }

    return render(request, "index.html",  context=context)

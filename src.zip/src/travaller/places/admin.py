from django.contrib import admin # type: ignore
from places.models import Places, Category, Gallery

class GalleryAdmin(admin.TabularInline):
    list_display = ["place", "image"]
    model = Gallery

class PlaceAdmin(admin.ModelAdmin):
    list_display = ["name", "place", "category"]
    inlines = [GalleryAdmin]

admin.site.register(Places, PlaceAdmin)
admin.site.register(Category)

from django.urls import path # type: ignore
from . import views

urlpatterns = [
    path('', views.places, name='places'),
    path('view/<int:pk>/', views.place, name='place'),
]

from rest_framework.serializers import ModelSerializer # type: ignore
from places.models import Places

class PlaceSerializer(ModelSerializer):
    class Meta:
        model = Places
        fields = ("id", "name", "featured_image", "place", "category", "description", "is_deleted")

from rest_framework.decorators import api_view  # type: ignore
from rest_framework.response import Response  # type: ignore

from api.V1.places.serializer import PlaceSerializer  # type: ignore
from places.models import Places  # type: ignore


@api_view(["GET"])
def places(request, pk):
    instances = Places.objects.filter(is_deleted=False)
    serializer = PlaceSerializer(instances, many=True)
    response_data = {
        "status_code": 6000,
        "data": serializer.data
    }
    return Response(response_data)


@api_view(["GET"])
def place(request, pk):
    if Places.objects.filter(pk=pk).exists():
        instance = Places.objects.get(pk=pk)
        context = {
            "request": request
        }
        serializer = PlaceSerializer(instance, context=context)

        response_data = {
            "status_code": 6000,
            "data": serializer.data
        }
        return Response(response_data)
    else:
        response_data = {
            "status_code": 6001,
            "message": "Place not found"
        }

